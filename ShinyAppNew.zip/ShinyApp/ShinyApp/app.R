#################################################################
## Practical 6 for GEOM184 - Open Source GIS                   ##
## 05/11/2026                                                  ##
## Creating a ShinyApp - Unified app.R                         ##
## Original code by Diego Panici (d.panici@exeter.ac.uk)       ##
##                                                             ##
## Edited with the assistance of Claude (Anthropic AI):        ##
## Claude was used to modify Panici's original code, adding    ##
## the "Chart" tab (large wood count per bridge), changing     ##
## file paths to relative paths for deployment, and limiting   ##
## the nearest-bridge assignment to wood north of each bridge. ##
#################################################################

# Run once, then leave commented out:
# install.packages(c("shiny", "leaflet", "sf", "raster", "RColorBrewer", "terra", "leafem", "dbscan", "elevatr"))

library(shiny)
library(leaflet)
library(sf)
library(raster)
library(RColorBrewer)
library(terra)
library(leafem)
library(dbscan)

options(shiny.maxRequestSize = 1000 * 1024^2)

# Local convenience: if the data files are not in the current folder,
# switch to the ShinyApp folder. (Skipped automatically on shinyapps.io.)
if (!file.exists("Large_wood.gpkg") && dir.exists("C:/Localdata/GeoM184/ShinyApp")) {
  setwd("C:/Localdata/GeoM184/ShinyApp")
}

#################################################################
## G1 Load large wood, river, and bridge data                  ##
## (all files are read from the same folder as app.R)          ##
#################################################################
lw_points <- st_read("Large_wood.gpkg", layer = "large_wood")
river     <- st_read("Buffer2.gpkg")
bridges   <- st_read("BridgesIsonzo.shp")

# Load Flood Defences (GeoPackages in EPSG:3857)
upstream     <- st_read("Upstream.gpkg")
midstream    <- st_read("Midstream.gpkg")
addmidstream <- st_read("AddMidstream.gpkg")

# Add descriptive labels for LW_Type safely
if ("LW_Type" %in% names(lw_points)) {
  lw_points$Type_Desc <- ifelse(lw_points$LW_Type == "LW", "Single Large Wood",
                                ifelse(lw_points$LW_Type == "CLSTR", "Wood Cluster",
                                       ifelse(lw_points$LW_Type == "BLC", "Wood Blockage", "Unknown")))
} else {
  lw_points$Type_Desc <- "Unknown"
}

# Perform Clustering in metric units ----
lw_proj <- st_transform(lw_points, crs = 3857)
lw_coords_metric <- st_coordinates(lw_proj)

cluster_res <- dbscan(lw_coords_metric, eps = 125, minPts = 6)
lw_points$CLUSTER_ID <- as.factor(cluster_res$cluster)

# Transform everything to EPSG:4326 for Leaflet ----
lw_points    <- st_transform(lw_points, crs = 4326)
river        <- st_transform(river, crs = 4326)
bridges      <- st_transform(bridges, crs = 4326)
upstream     <- st_transform(upstream, crs = 4326)
midstream    <- st_transform(midstream, crs = 4326)
addmidstream <- st_transform(addmidstream, crs = 4326)

# Colours per cluster (noise = 0 -> grey), precomputed as plain columns
cl_ids  <- sort(setdiff(unique(as.character(lw_points$CLUSTER_ID)), "0"))
cl_cols <- colorRampPalette(brewer.pal(12, "Paired"))(max(length(cl_ids), 1))

lw_points$fill_col <- ifelse(
  as.character(lw_points$CLUSTER_ID) == "0", "grey",
  cl_cols[match(as.character(lw_points$CLUSTER_ID), cl_ids)]
)

lw_points$popup_txt <- paste0(
  "<b>ID:</b> ", lw_points$id,
  "<br><b>LW Type Code:</b> ", lw_points$LW_Type,
  "<br><b>Description:</b> ", lw_points$Type_Desc,
  "<br><b>Cluster ID:</b> ", lw_points$CLUSTER_ID
)

# Load and properly project raster for Leaflet ----
heatmap_raw <- raster("Heatmap2_small.tif")
heatmap_raw[heatmap_raw <= 0] <- NA
heatmap_leaflet <- projectRasterForLeaflet(heatmap_raw, method = "bilinear")

vals <- raster::values(heatmap_leaflet)
rng  <- range(vals, na.rm = TRUE)

pal_heatmap <- colorNumeric("Spectral", domain = rng, reverse = TRUE, na.color = "transparent")

# Extra layers: slope, aspect, nearest distance lines ----
prep_raster <- function(r) {
  list(raw = r, leaflet = projectRasterForLeaflet(r, method = "bilinear"))
}

dem_cache <- "DEM_downloaded.tif"

dem <- NULL
if (file.exists(dem_cache)) {
  dem <- terra::rast(dem_cache)
} else {
  dem <- tryCatch({
    if (!requireNamespace("elevatr", quietly = TRUE)) stop("elevatr is not installed")
    aoi   <- sf::st_sf(geometry = sf::st_as_sfc(sf::st_bbox(river)))   
    dem_dl <- elevatr::get_elev_raster(locations = aoi, z = 12, clip = "bbox")  
    d <- terra::rast(dem_dl)
    terra::writeRaster(d, dem_cache, overwrite = TRUE)
    d
  }, error = function(e) {
    warning("Could not build a DEM, Slope and Aspect layers skipped: ", conditionMessage(e))
    NULL
  })
}

slope_layer  <- NULL
aspect_layer <- NULL
if (!is.null(dem)) {
  dem_utm <- terra::project(dem, "EPSG:32633")
  max_cells <- 1e6
  fact <- ceiling(sqrt(terra::ncell(dem_utm) / max_cells))
  if (fact > 1) dem_utm <- terra::aggregate(dem_utm, fact = fact, fun = "mean", na.rm = TRUE)
  
  slope_layer  <- prep_raster(raster::raster(terra::terrain(dem_utm, v = "slope",  unit = "degrees")))
  aspect_layer <- prep_raster(raster::raster(terra::terrain(dem_utm, v = "aspect", unit = "degrees")))
}

if (!is.null(slope_layer)) {
  pal_slope <- colorNumeric("YlOrRd", domain = range(raster::values(slope_layer$leaflet), na.rm = TRUE),
                            na.color = "transparent")
}
pal_aspect <- colorNumeric(
  colorRampPalette(c("#2c7bb6", "#00a6ca", "#abd9e9", "#ffffbf", "#fdae61", "#d7191c", "#2c7bb6"))(256),
  domain = c(0, 360), na.color = "transparent"
)

#################################################################
## Nearest bridge assignment - NORTH OF BRIDGE ONLY            ##
## [Edited with Claude]                                        ##
## A large wood piece can only belong to a bridge that lies    ##
## south of it (bridge northing < wood northing). Among those  ##
## bridges the nearest one wins. No distance limit is applied. ##
#################################################################
lw_utm      <- st_transform(lw_points, crs = 32633)
bridges_utm <- st_transform(bridges,   crs = 32633)

# Distance (m) from every large wood piece (rows) to every bridge (columns)
dist_mat <- matrix(as.numeric(st_distance(lw_utm, bridges_utm)), nrow = nrow(lw_utm))

# TRUE where the wood is north of the bridge
lw_north <- st_coordinates(lw_utm)[, 2]
br_north <- st_coordinates(bridges_utm)[, 2]
is_north <- outer(lw_north, br_north, ">")

# Bridges that are not south of the wood cannot claim it
dist_mat[!is_north] <- Inf

min_d       <- apply(dist_mat, 1, min)
has_bridge  <- is.finite(min_d)
nearest_idx <- apply(dist_mat, 1, which.min)
nearest_idx[!has_bridge] <- NA_integer_

# Wood south of every bridge has no bridge to belong to
n_unassigned <- sum(!has_bridge)

# Lines from each assigned wood piece to its bridge
ok <- which(has_bridge)
nearest_geom <- st_nearest_points(lw_utm[ok, ], bridges_utm[nearest_idx[ok], ], pairwise = TRUE)
nearest <- st_sf(
  lw_id   = lw_points$id[ok],
  dist_m  = as.numeric(st_length(nearest_geom)),
  geometry = nearest_geom
)
nearest <- st_transform(nearest, crs = 4326)

nearest_group <- "Nearest Distance (Bridges & Large Wood)"

#################################################################
## Bridge labels and large wood assignment (for the chart)     ##
## [Added with Claude]                                         ##
#################################################################
# Pick the column holding the bridge name (name -> id -> first column -> row number)
bridge_df_all <- sf::st_drop_geometry(bridges)
name_col <- {
  nm <- names(bridge_df_all)
  hit <- nm[tolower(nm) == "name"]
  if (length(hit) == 0) hit <- nm[tolower(nm) == "id"]
  if (length(hit) == 0 && length(nm) > 0) hit <- nm[1]
  if (length(hit) == 0) NA_character_ else hit[1]
}

bridge_labels <- if (!is.na(name_col)) {
  as.character(bridge_df_all[[name_col]])
} else {
  as.character(seq_len(nrow(bridges)))
}
bridge_labels[is.na(bridge_labels) | bridge_labels == ""] <- "Unnamed"
bridge_labels <- make.unique(bridge_labels, sep = " #")

# One row per large wood piece: which bridge it belongs to and how far away (m)
# (NA where the wood is south of every bridge)
lw_bridge <- data.frame(
  lw_id      = lw_points$id,
  bridge_idx = nearest_idx,
  dist_m     = ifelse(has_bridge, min_d, NA_real_)
)

max_dist_all <- ceiling(max(lw_bridge$dist_m, na.rm = TRUE))

add_extra_raster <- function(map, layer, pal, group, pane) {
  if (is.null(layer)) return(map)
  addRasterImage(map, layer$leaflet, colors = pal, opacity = 0.7, project = FALSE,
                 group = group, options = list(pane = pane))
}

raster_layers <- list(Heatmap = list(raw = heatmap_raw, unit = ""))
if (!is.null(slope_layer))  raster_layers$Slope  <- list(raw = slope_layer$raw,  unit = "&deg;")
if (!is.null(aspect_layer)) raster_layers$Aspect <- list(raw = aspect_layer$raw, unit = "&deg;")

overlay_groups <- c(
  "Wood Catchers", "Large Wood",
  if (!is.null(nearest)) nearest_group,
  "Heatmap",
  if (!is.null(slope_layer))  "Slope",
  if (!is.null(aspect_layer)) "Aspect",
  "Bridges", "River Buffer Zone"
)

# Safe Bridge Popups Construction
bridge_attrs <- sf::st_drop_geometry(bridges)
col_nms <- names(bridge_attrs)
if (!is.null(col_nms) && length(col_nms) > 0) {
  keep_cols <- col_nms[col_nms != "" & tolower(col_nms) %in% c("id", "name")]
  if (length(keep_cols) == 0) keep_cols <- col_nms[col_nms != ""]
  bridge_attrs <- bridge_attrs[, keep_cols, drop = FALSE]
}

if (ncol(bridge_attrs) > 0) {
  bridge_popup <- vapply(seq_len(nrow(bridge_attrs)), function(i) {
    vals <- vapply(bridge_attrs[i, , drop = TRUE], function(x) as.character(x[1]), character(1))
    paste0(
      "<b>Bridge</b><br>",
      paste0("<b>", names(bridge_attrs), ":</b> ", vals, collapse = "<br>")
    )
  }, character(1))
} else {
  bridge_popup <- rep("<b>Bridge</b>", nrow(bridges))
}

#################################################################
## UI.R - Define UI for visualisation                          ##
#################################################################
ui <- navbarPage(
  title = "Instream large wood on the River Isonzo",
  id = 'nav',
  tabPanel("Map",
           leafletOutput("map", height = "calc(100vh - 70px)")
  ),
  tabPanel("Chart",
           sidebarLayout(
             sidebarPanel(
               width = 3,
               h4("Large wood per bridge"),
               p("Each large wood piece is assigned to the nearest bridge that lies south of it (wood is only counted north of a bridge)."),
               p(paste0(n_unassigned, " large wood piece(s) lie south of every bridge and are not counted.")),
               sliderInput("max_dist", "Maximum distance to bridge (m):",
                           min = 0, max = max_dist_all, value = max_dist_all,
                           step = 50, ticks = FALSE),
               checkboxInput("sort_bars", "Sort bridges by count", value = TRUE),
               radioButtons("chart_type", "Chart type:",
                            choices = c("Bar", "Line"), selected = "Bar",
                            inline = TRUE)
             ),
             mainPanel(
               width = 9,
               plotOutput("bridge_plot", height = "600px")
             )
           )
  )
)

#################################################################
## Server.R - Operations and Leaflet map rendering             ##
#################################################################
server <- function(input, output, session) {
  
  # S1 Render leaflet map
  output$map <- renderLeaflet({
    leaflet() %>%
      setView(lng = 13.533545, lat = 45.850065, zoom = 11.3) %>%
      
      addMapPane("riverPane",   zIndex = 310) %>%   
      addMapPane("slopePane",   zIndex = 330) %>%   
      addMapPane("aspectPane",  zIndex = 340) %>%   
      addMapPane("heatmapPane", zIndex = 350) %>%   
      addMapPane("bridgePane",  zIndex = 380) %>%   
      addMapPane("nearestPane", zIndex = 390) %>%   
      addMapPane("woodPane",    zIndex = 410) %>%   
      addMapPane("catcherPane", zIndex = 420) %>%   
      
      addTiles(
        urlTemplate = "https://{s}.google.com/vt/lyrs=s&x={x}&y={y}&z={z}",
        attribution = 'Tiles &copy; Google',
        options = tileOptions(subdomains = c('mt0', 'mt1', 'mt2', 'mt3'), maxZoom = 20),
        group = "Google Satellite"
      ) %>%
      
      # 1. River Buffer Zone
      addPolygons(
        data = river, color = "slateblue", weight = 1, opacity = 1.0,
        fillColor = "slateblue", fillOpacity = 1.0, group = "River Buffer Zone",
        options = pathOptions(pane = "riverPane")
      ) %>%
      
      # 2. Heatmap
      addRasterImage(
        heatmap_leaflet, colors = pal_heatmap,
        opacity = 1.0, project = FALSE, group = "Heatmap",
        options = list(pane = "heatmapPane")
      ) %>%
      
      # 2b. Slope and Aspect
      add_extra_raster(slope_layer,  pal_slope,  "Slope",  "slopePane") %>%
      add_extra_raster(aspect_layer, pal_aspect, "Aspect", "aspectPane") %>%
      
      # 3b. Nearest distance lines
      {
        if (!is.null(nearest)) {
          addPolylines(
            ., data = nearest, color = "black", weight = 2, opacity = 0.8,
            group = nearest_group,
            options = pathOptions(pane = "nearestPane", clickable = FALSE)
          )
        } else .
      } %>%
      
      # 3. Bridges
      {
        b_coords <- st_coordinates(bridges)
        offset_x <- 0.003
        offset_y <- 0.0012
        addRectangles(
          .,
          lng1 = b_coords[,1] - offset_x, lat1 = b_coords[,2] - offset_y,
          lng2 = b_coords[,1] + offset_x, lat2 = b_coords[,2] + offset_y,
          color = "black", fillColor = "indianred",
          fillOpacity = 0.9, weight = 1.5, group = "Bridges",
          popup = bridge_popup,
          options = pathOptions(pane = "bridgePane", bubblingMouseEvents = FALSE)
        )
      } %>%
      
      # 4. Large Wood
      addCircleMarkers(
        data = lw_points,
        fillColor = ~fill_col,
        color = "black",
        weight = 1,
        radius = 5,
        stroke = TRUE,
        fillOpacity = 1.0,
        popup = ~popup_txt,
        group = "Large Wood",
        options = pathOptions(pane = "woodPane", bubblingMouseEvents = FALSE)
      ) %>%
      
      # 5. Wood Catchers
      addPolylines(data = upstream, color = "yellow", weight = 3, opacity = 0.9,
                   popup = ~paste("<b>Wood Catcher: Upstream</b><br>ID:", id),
                   group = "Wood Catchers",
                   options = pathOptions(pane = "catcherPane", bubblingMouseEvents = FALSE)) %>%
      addPolylines(data = midstream, color = "red", weight = 3, opacity = 0.9,
                   popup = ~paste("<b>Wood Catcher: Midstream</b><br>ID:", id),
                   group = "Wood Catchers",
                   options = pathOptions(pane = "catcherPane", bubblingMouseEvents = FALSE)) %>%
      addPolylines(data = addmidstream, color = "magenta", weight = 3, opacity = 0.9,
                   popup = ~paste("<b>Wood Catcher: Additional midstream</b><br>ID:", id),
                   group = "Wood Catchers",
                   options = pathOptions(pane = "catcherPane", bubblingMouseEvents = FALSE)) %>%
      
      addLayersControl(
        baseGroups = c("Google Satellite"),
        overlayGroups = overlay_groups,
        options = layersControlOptions(collapsed = FALSE)
      ) %>%
      
      hideGroup("Large Wood") %>%
      hideGroup("Bridges") %>%
      hideGroup(nearest_group) %>%
      hideGroup("Slope") %>%
      hideGroup("Aspect")
  })
  
  observeEvent(input$map_click, {
    click <- input$map_click
    if (is.null(click)) return()
    
    proxy <- leafletProxy("map")
    visible <- input$map_groups
    lines <- character(0)
    
    for (g in names(raster_layers)) {
      if (!(g %in% visible)) next
      r <- raster_layers[[g]]$raw
      
      pt <- sf::st_sfc(sf::st_point(c(click$lng, click$lat)), crs = 4326)
      pt <- sf::st_transform(pt, sf::st_crs(raster::crs(r)))
      val <- raster::extract(r, matrix(sf::st_coordinates(pt), ncol = 2))
      
      if (length(val) == 1 && !is.na(val)) {
        label <- if (g == "Heatmap") "Heatmap Value" else g
        lines <- c(lines, paste0("<b>", label, ":</b> ",
                                 format(round(val, 2), nsmall = 2),
                                 raster_layers[[g]]$unit))
      }
    }
    
    proxy %>% clearPopups()
    if (length(lines) > 0) {
      proxy %>% addPopups(lng = click$lng, lat = click$lat,
                          popup = paste(lines, collapse = "<br>"))
    }
  })
  
  # S2 Large wood count per bridge [Added with Claude]
  bridge_counts <- reactive({
    max_d <- if (is.null(input$max_dist)) max_dist_all else input$max_dist
    keep  <- !is.na(lw_bridge$dist_m) & lw_bridge$dist_m <= max_d
    
    counts <- tabulate(lw_bridge$bridge_idx[keep], nbins = length(bridge_labels))
    d <- data.frame(bridge = bridge_labels, count = counts,
                    stringsAsFactors = FALSE)
    
    if (isTRUE(input$sort_bars)) d <- d[order(-d$count, d$bridge), ]
    d
  })
  
  output$bridge_plot <- renderPlot({
    d <- bridge_counts()
    max_d <- if (is.null(input$max_dist)) max_dist_all else input$max_dist
    ttl <- paste0("Large wood count by bridge (north of bridge, within ", max_d, " m)")
    y_max <- max(d$count, 1) * 1.15
    
    op <- par(mar = c(10, 5, 4, 1))
    on.exit(par(op), add = TRUE)
    
    if (identical(input$chart_type, "Line")) {
      x <- seq_len(nrow(d))
      plot(x, d$count, type = "b", pch = 19, lwd = 2, col = "indianred",
           xaxt = "n", xlab = "", ylab = "Number of large wood pieces",
           ylim = c(0, y_max), main = ttl)
      axis(1, at = x, labels = d$bridge, las = 2, cex.axis = 0.8)
      text(x, d$count, labels = d$count, pos = 3)
      grid(nx = NA, ny = NULL)
    } else {
      bp <- barplot(d$count, names.arg = d$bridge, las = 2, cex.names = 0.8,
                    col = "indianred", border = "black",
                    ylab = "Number of large wood pieces",
                    ylim = c(0, y_max), main = ttl)
      text(bp, d$count, labels = d$count, pos = 3)
    }
  })
}

#################################################################
## Run Application                                             ##
#################################################################
shinyApp(ui, server)